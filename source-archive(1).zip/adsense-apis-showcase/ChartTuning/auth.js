/*
 * Copyright 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Provides functions to perform the OAuth 2.0 authentication.
 * @author silvano.luciani@gmail.com (Silvano Luciani)
 */

goog.require('goog.dom');
goog.require('goog.dom.classes');
goog.require('goog.events');

/**
 * Enter a client ID for a web application from the Google Developer Console.
 * In your Developer Console project, add a JavaScript origin that corresponds
 * to the domain where you will be running the script.
 * @type {string}
 */
CLIENT_ID = 'INSERT_YOUR_CLIENT_ID_HERE';

/**
 * Enter the API key from the Google Developer Console - to handle any
 * unauthenticated requests in the code.
 * @type {string}
 */
API_KEY = 'INSERT_YOUR_API_KEY_HERE';

/**
 * To enter one or more authentication scopes, refer to the documentation
 * for the API.
 * @type {string}
 */
SCOPE = 'https://www.googleapis.com/auth/adsense.readonly';


/**
 * Set the api key and starts the authentication flow calling checkAuth.
 * Called from the example page after the Google APIs Javascript client has been
 * loaded.
 */
function handleClientLoad() {
  gapi.client.setApiKey(API_KEY);
  window.setTimeout(checkAuth, 1);
}

/**
 * Checks the authorization and calls handleAuthResult once the process
 * is completed.
 */
function checkAuth() {
  gapi.auth.authorize({client_id: CLIENT_ID, scope: SCOPE, immediate: true},
      handleAuthResult);
}

/**
 * Performs the API request if we have an access token, otherwise shows the
 * authentication button to allow the user to start the flow.
 * makeApiCall is implemented in each specific code example to query the API and
 * visualize the data.
 * @param {object} authResult An OAuth 2.0 token and any associated data.
 */
function handleAuthResult(authResult) {
  var authorizeButton = goog.dom.getElement('authorizeButton');
  if (authResult) {
    goog.dom.classes.addRemove(authorizeButton, 'active', 'inactive');
    makeApiCall();
  } else {
    goog.dom.classes.addRemove(authorizeButton, 'inactive', 'active');
    goog.events.listen(authorizeButton, 'click', handleAuthClick);
  }
}

/**
 * Handles authentication requests from the authentication button.
 * @param {object} event The event that triggered the function.
 */
function handleAuthClick(event) {
  gapi.auth.authorize({client_id: CLIENT_ID, scope: SCOPE, immediate: false},
      handleAuthResult);
}

